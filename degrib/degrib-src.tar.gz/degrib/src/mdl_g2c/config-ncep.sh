# Sample configure options for making mdl_g2c on NCEP's AIX system
#
configure CC="xlc" CFLAGS="-O" --with-libaat=../aat --with-zlib=/usrx/local/64bit/zlib-1.1.4 --with-libpng=/usrx/local/64bit/libpng-1.2.5 --with-jpeg2000=/usrx/local/64bit/jasper-1.700.2/src/libjasper/include
