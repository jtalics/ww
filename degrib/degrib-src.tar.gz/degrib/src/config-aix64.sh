#!/bin/sh
./configure CC=cc CFLAGS="-O" TCL_PREFIX=/mdl2/save/bin/tcltk TCL_VERSION=8.5
