/*
 * $Id: ncio.c,v 2.2 1996/03/11 16:44:42 steve Exp $
 */

#if defined(_CRAY)
#   include "ffio.c"
#else
#   include "posixio.c"
#endif
